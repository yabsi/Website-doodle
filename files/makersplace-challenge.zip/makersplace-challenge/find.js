const Web3 = require('web3');
const cEthAbi = require('./abi.json');

const web3 = new Web3('https://mainnet.infura.io/v3/83dd91ed813b44049c428672c8e94fa2');
const cEthAddress = '0x06012c8cf97BEaD5deAe237070F9587f8E7A266d';
const cEthContract = new web3.eth.Contract(cEthAbi, cEthAddress);

async function getPastBirthEvents(fromBlock, toBlock) {
    if (fromBlock <= toBlock) {
        try {
            const options = {
                fromBlock: fromBlock,
                toBlock  : toBlock
            };
            return await cEthContract.getPastEvents('Birth', options);
        }
        catch (error) {
            const midBlock = (fromBlock + toBlock) >> 1;
            const arr1 = await getPastBirthEvents(fromBlock, midBlock);
            const arr2 = await getPastBirthEvents(midBlock + 1, toBlock);
            return [...arr1, ...arr2];
        }
    }
    return [];
}

async function findBigMamaKitty(pastBirthEvents) {
    const birthsMap = {};
    let bigMamaId;
    let maxBirths = 0;

    pastBirthEvents.forEach(event => {
      const matronId = event.returnValues.matronId;
      if(matronId == 0)
        return;
      birthsMap[matronId] = (birthsMap[matronId] == null ?  0 : birthsMap[matronId]) + 1
      if (birthsMap[matronId] > maxBirths) {
          maxBirths = birthsMap[matronId];
          bigMamaId = matronId;
      }
    });

    return bigMamaId;
}

async function getKittyStats(kittyId){
    return cEthContract.methods.getKitty(kittyId).call().then((kitty) => ({
      kittyId,
      birthTime: kitty.birthTime,
      generation: kitty.generation,
      genes: kitty.genes
    }));
}

async function start() {
    const args = process.argv.slice(2);
    if(args[0] == undefined || args[1] == undefined){
      console.log("Please add the block numbers")
      return;
    }
    const fromBlock = Number(args[0]); // 6607985
    const toBlock = Number(args[1]); // 7028323
    const pastBirthEvents = await getPastBirthEvents(fromBlock, toBlock);
    const totalBirths = pastBirthEvents.length;
    const bigMamaId = await findBigMamaKitty(pastBirthEvents);
    const bigMamaStats = await getKittyStats(bigMamaId);

    console.log(totalBirths); // 186652
    console.log(bigMamaStats);
};

start();
